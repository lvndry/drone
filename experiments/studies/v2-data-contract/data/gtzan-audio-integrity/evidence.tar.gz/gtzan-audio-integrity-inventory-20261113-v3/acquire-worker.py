import json,pathlib,time
from tools.check_gtzan_audio import audit
ROOT=pathlib.Path('/home/lysk-admin/drone-experiments/gtzan-audio-integrity-inventory-20261113-v3')
start=time.monotonic()
result=audit(pathlib.Path('/home/lysk-admin/drone-experiments/gtzan-audio-integrity-20261113-v1/genres.tar.gz'), inventory_only=True)
with (ROOT/'audio-integrity.json').open('x') as out:json.dump(result,out,indent=2,sort_keys=True);out.write('\n')
print(json.dumps({'recordings_inspected':len(result['records']),'admitted_for_scoring':False,'elapsed_seconds':time.monotonic()-start}),flush=True)
