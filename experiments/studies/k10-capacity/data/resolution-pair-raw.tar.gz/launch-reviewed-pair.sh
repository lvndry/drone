#!/bin/sh
set -eu
pair_root=/home/lysk-admin/drone-experiments/k10-resolution-pair-20261112-seed13-v1
test -f "$pair_root/approval-final.json"
test ! -e "$pair_root/run-v1"
cd "$pair_root/source"
exec env CUDA_VISIBLE_DEVICES=GPU-9c2004f9-0d41-d7c7-7075-863335543ee8 \
  OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
  CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONDONTWRITEBYTECODE=1 \
  taskset -c 10,11 nice -n 19 /home/lysk-admin/drone/.venv/bin/python \
  -m tools.run_k10_resolution_fit --config "$pair_root/sealed-config.json" \
  --approval "$pair_root/approval-final.json" --output-root "$pair_root/run-v1"
