def checkpoint(
    path: Path, model: torch.nn.Module, provenance: dict[str, Any], watch: Callable[[], None]
) -> str:
    import torch

    watch()
    temporary = path.with_suffix(".pending")
    torch.save(
        {
            "format": "EXPERIMENTAL_K10_CONTEXT_STATE_DICT_V1",
            "state_dict": model.state_dict(),
            "provenance": provenance,
        },
        temporary,
    )
    watch()
    temporary.replace(path)
    return sha(path)

def evaluate_complete(
    model: torch.nn.Module, full: list[np.ndarray], watch: Callable[[], None]
) -> np.ndarray:
    import torch

    from train import evaluate_features

    counts = {"tracks": 0, "frames": 0}

    class Finite(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.base = model

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            watch()
            y = self.base(x)
            if (
                y.shape != (x.shape[0], 24)
                or y.dtype != torch.float32
                or not bool(torch.isfinite(y).all())
            ):
                raise ValueError("Invalid full-song FP32 logits")
            counts["tracks"] += x.shape[0]
            counts["frames"] += x.shape[0] * x.shape[2]
            return y

    predictions = evaluate_features(Finite(), full, "cpu", batch=4)
    if (
        predictions.shape != (len(full),)
        or not np.issubdtype(predictions.dtype, np.integer)
        or np.any((predictions < 0) | (predictions >= 24))
        or counts["tracks"] != len(full)
        or counts["frames"] != sum(x.shape[1] for x in full)
    ):
        raise ValueError("Incomplete full-song prediction coverage/shape/range")
    return predictions

def train_arm(
    length: int,
    p: dict[str, Any],
    rows: dict[str, dict[str, Any]],
    array: Callable[[str], np.ndarray],
    output: Path,
    provenance: dict[str, Any],
    watch: Callable[[], None],
) -> dict[str, Any]:
    import torch

    from drone.features import window
    from drone.keys import transpose_key
    from drone.model import KeyCNN

    torch.manual_seed(13)
    model = KeyCNN().to("cpu")
    digest = hashlib.sha256()
    for name, value in model.state_dict().items():
        digest.update(name.encode())
        digest.update(value.numpy().tobytes())
    if digest.hexdigest() != INITIAL:
        raise ValueError("Fresh initialization differs from qualified seed13")
    output.mkdir(exist_ok=False)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.0001)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, EVENTS)
    panels = {"beatport": p["bp_selection_guard"], "fmak": p["fma_inner_selection"]}
    ids = panels["beatport"] + panels["fmak"]
    refs = {i: r["ref"] for i, r in rows.items()}
    full = [window(array(i)).astype(np.float32) for i in ids]
    common, temporal, bp = hashlib.sha256(), hashlib.sha256(), hashlib.sha256()
    exposure = Counter()
    coverage = Counter()
    history = []
    loss_sum = 0.0
    best = None
    best_metrics = None
    best_update = None
    start = time.monotonic()
    for update, batch in enumerate(
        paired_batches(p["bp_fit"], p["expanded_fma_fit"], updates=UPDATES), 1
    ):
        watch()
        xs = []
        targets = []
        for draw in batch:
            x, w = make_crop(array(draw.identity), draw, length)
            xs.append(x)
            targets.append(transpose_key(refs[draw.identity], -w["shift"]))
            common.update(
                f"{draw.domain}:{draw.identity}:{draw.augmentation_seed}:{w['shift']}\n".encode()
            )
            temporal.update(
                f"{draw.identity}:{draw.augmentation_seed}:{w['shift']}:{w['first']}\n".encode()
            )
            if draw.domain == "beatport":
                bp.update(
                    f"{draw.identity}:{draw.augmentation_seed}:{w['shift']}:{w['first']}\n".encode()
                )
            coverage[draw.identity] += 1
            exposure[draw.domain] += w["actual_frames"]
        model.train()
        optimizer.zero_grad()
        loss = torch.nn.functional.cross_entropy(
            model(torch.from_numpy(np.stack(xs))), torch.tensor(targets)
        )
        if not bool(torch.isfinite(loss)):
            raise ValueError("Nonfinite training loss")
        loss.backward()
        if any(
            t.grad is not None and not bool(torch.isfinite(t.grad).all())
            for t in model.parameters()
        ):
            raise ValueError("Nonfinite gradients; no optimizer commit")
        optimizer.step()
        loss_sum += float(loss.detach())
        if any(not bool(torch.isfinite(t).all()) for t in model.state_dict().values()):
            raise ValueError("Nonfinite updated state")
        if update % EVERY:
            continue
        scheduler.step()  # Same timing as original K10 v2 driver.
        predictions = evaluate_complete(model, full, watch)
        measured = {
            d: metrics(
                domain_ids,
                predictions[
                    (0 if d == "beatport" else 126) : (126 if d == "beatport" else len(ids))
                ].tolist(),
                refs,
            )
            for d, domain_ids in panels.items()
        }
        key = selection_key(measured)
        if best is None or key > best:
            best, best_update, best_metrics = key, update, measured
            best_sha = checkpoint(
                output / "best.pt",
                model,
                {**provenance, "crop_frames": length, "selected_update": update},
                watch,
            )
        history.append({"update": update, "train_ce": loss_sum / EVERY, "metrics": measured})
        loss_sum = 0.0
        save_or_replace(
            output / "progress.json",
            {
                "complete": False,
                "updates": update,
                "events": len(history),
                "best_update": best_update,
                "history": history,
            },
        )
        watch()
    if update != UPDATES or len(history) != EVENTS:
        raise ValueError("Incomplete fixed horizon")
    if best_metrics is None or best_update is None:
        raise ValueError("No selected checkpoint")
    final_sha = checkpoint(
        output / "final.pt",
        model,
        {**provenance, "crop_frames": length, "final_update": update},
        watch,
    )
    if sha(output / "best.pt") != best_sha:
        raise ValueError("Selected checkpoint changed before reload")
    payload = torch.load(output / "best.pt", map_location="cpu", weights_only=True)
    expected_metadata = {**provenance, "crop_frames": length, "selected_update": best_update}
    if (
        payload.get("format") != "EXPERIMENTAL_K10_CONTEXT_STATE_DICT_V1"
        or payload["provenance"] != expected_metadata
    ):
        raise ValueError("Selected checkpoint metadata differs")
    restored = KeyCNN().to("cpu")
    restored.load_state_dict(payload["state_dict"], strict=True)
    reloaded = evaluate_complete(restored, full, watch)
    expected_predictions = (
        best_metrics["beatport"]["predictions"] + best_metrics["fmak"]["predictions"]
    )
    if not np.array_equal(reloaded, np.asarray(expected_predictions)):
        raise ValueError("Selected checkpoint reload prediction identity failed")
    result = {
        "status": "COMPLETE_CONTEXT_ARM_NOT_PROMOTED",
        "crop_frames": length,
        "updates": update,
        "events": EVENTS,
        "initial_state_sha256": digest.hexdigest(),
        "best_update": best_update,
        "best_metrics": best_metrics,
        "best_checkpoint_sha256": best_sha,
        "final_checkpoint_sha256": final_sha,
        "history": history,
        "common_draw_pitch_sha256": common.hexdigest(),
        "temporal_sha256": temporal.hexdigest(),
        "bp_augmented_sha256": bp.hexdigest(),
        "coverage": dict(coverage),
        "actual_frames": dict(exposure),
        "elapsed_seconds": time.monotonic() - start,
        "provenance": provenance,
        "confirmation_used": False,
        "calibration_used": False,
        "selected_reload_proof": {
            "strict_state_load": True,
            "tracks": len(ids),
            "frames": sum(x.shape[1] for x in full),
            "argmax_disagreements": 0,
            "scores_identical": True,
            "checkpoint_sha256": best_sha,
        },
    }
    watch()
    save(output / "result.json", result)
    return result
