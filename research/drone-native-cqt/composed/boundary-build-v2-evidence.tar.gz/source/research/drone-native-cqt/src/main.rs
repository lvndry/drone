//! Identical-PCM research feasibility; no decoder, labels, accuracy scoring or promotion.
use anyhow::{Context, Result, ensure};
use clap::Parser;
use drone_native_cached::{
    Full, argmax, bytes_sha256, check_file, compare, environment, file_sha256,
};
use drone_native_cqt::{artifact_root, diagnostics, plan, read_f32};
use serde_json::{Value, json};
use std::{fs, path::PathBuf};
mod owner {
    include!(concat!(env!("OUT_DIR"), "/owner.rs"));
}
#[derive(Parser)]
struct Args {
    #[arg(long)]
    numpy_magnitude: bool,
    #[arg(long)]
    math_library: Option<PathBuf>,
    #[arg(long)]
    math_library_sha256: Option<String>,
    #[arg(long)]
    single_case: bool,
    #[arg(long)]
    expect_manifest_sha256: Option<String>,
    #[arg(long, default_value = "owner")]
    candidate: String,
    #[arg(long)]
    soxr_wrapper: Option<PathBuf>,
    #[arg(long)]
    manifest: PathBuf,
    #[arg(long)]
    full_model: PathBuf,
    #[arg(long)]
    ort_library: PathBuf,
    #[arg(long)]
    output: PathBuf,
}

fn main() -> Result<()> {
    let args = Args::parse();
    ensure!(!args.output.exists(), "immutable output exists");
    ensure!(
        args.candidate != "owner" || cfg!(owner_snapshot),
        "owner candidate requires explicit external snapshot at build"
    );
    ensure!(
        matches!(args.candidate.as_str(), "owner" | "exported"),
        "unknown candidate"
    );
    let manifest: Value = serde_json::from_slice(&fs::read(&args.manifest)?)?;
    if args.single_case {
        ensure!(
            args.candidate == "exported",
            "failed owner candidate is not qualified for expansion"
        );
        check_file(
            &args.manifest,
            args.expect_manifest_sha256
                .as_deref()
                .context("single case requires expected manifest hash")?,
        )?;
        ensure!(
            manifest["complete"] == true
                && manifest["tracks"] == 1
                && manifest["format"] == "k10-cqt-expansion-case-v1"
                && manifest["expected_study_tracks"] == 376,
            "incomplete/wrong expansion case"
        );
    } else {
        ensure!(
            manifest["complete"] == true
                && manifest["tracks"] == 9
                && manifest["format"] == "k10-cqt-goldens-v1",
            "incomplete/wrong goldens"
        );
    }
    check_file(
        &args.full_model,
        manifest["full_model_sha256"]
            .as_str()
            .context("model hash")?,
    )?;
    if let Some(library) = &args.math_library {
        ensure!(
            args.candidate == "exported",
            "math library is only supported by exported candidate"
        );
        check_file(
            library,
            args.math_library_sha256
                .as_deref()
                .context("math library requires expected SHA256")?,
        )?;
    } else {
        ensure!(
            args.math_library_sha256.is_none(),
            "math SHA without library"
        );
    }
    let environment = environment(&args.ort_library)?;
    let mut model = Full::new(&environment, &args.full_model)?;
    let math = args
        .math_library
        .as_deref()
        .map(plan::NumpyMath::new)
        .transpose()?;
    let root = artifact_root(&args.manifest)?;
    let cases = manifest["cases"].as_array().context("cases")?;
    if args.single_case {
        ensure!(cases.len() == 1, "exactly one expansion case required");
    } else {
        let expected = [
            "silence",
            "impulses",
            "tone",
            "major",
            "minor",
            "noise",
            "fmak-110544",
            "fmak-107354",
            "fmak-087373",
        ];
        ensure!(cases.len() == expected.len(), "exactly nine cases required");
        for (case, id) in cases.iter().zip(expected) {
            ensure!(
                case["id"].as_str() == Some(id),
                "frozen case membership/order changed"
            );
        }
    }
    ensure!(
        manifest["sample_rate"] == 22050
            && manifest["hop"] == 4096
            && manifest["bins"] == 208
            && manifest["core_slice"] == json!([8, 200]),
        "frontend contract mismatch"
    );
    let mut rows = Vec::new();
    let mut passed = true;
    for case in cases {
        let pcm = read_f32(root, &case["pcm"])?;
        let reference = read_f32(root, &case["core"])?;
        let (actual, frames, stage_diagnostics) = if args.candidate == "exported" {
            let soxr = plan::Soxr::new(
                args.soxr_wrapper
                    .as_deref()
                    .context("exported requires --soxr-wrapper")?,
            )?;
            plan::features(root, case, &pcm, &soxr, math.as_ref(), args.numpy_magnitude)?
        } else {
            let (values, frames) = owner::features(&pcm);
            (values, frames, json!({}))
        };
        ensure!(
            Some(frames as u64) == case["frames"].as_u64(),
            "frame mismatch"
        );
        let logits = model.predict(&actual, frames)?;
        let expected: Vec<f32> = case["reference_logits"]
            .as_array()
            .context("logits")?
            .iter()
            .map(|x| x.as_f64().map(|v| v as f32).context("logit"))
            .collect::<Result<_>>()?;
        let expected: [f32; 24] = expected
            .try_into()
            .map_err(|_| anyhow::anyhow!("24 logits"))?;
        let parity = compare(&logits, &expected)?;
        passed &= parity.allclose && parity.argmax_agrees;
        let row = json!({"id":case["id"],"pcm_sha256":case["pcm"]["sha256"],"frames":frames,"stage_diagnostics":stage_diagnostics,"features":diagnostics(&actual,&reference)?,"comparison":parity,"logits":logits,"argmax":argmax(&logits)?});
        eprintln!("{}", row);
        rows.push(row);
    }
    let result = json!({"format":"k10-native-cqt-feasibility-v1","candidate":args.candidate,"single_case":args.single_case,"numpy_magnitude":args.numpy_magnitude,"passed":passed,"gate":"finite logits; atol=1e-5 rtol=1e-5; zero argmax disagreement; fixed identical-PCM cases","manifest_sha256":file_sha256(&args.manifest)?,"full_model_sha256":file_sha256(&args.full_model)?,"ort_library_sha256":file_sha256(&args.ort_library)?,"executable_sha256":file_sha256(&std::env::current_exe()?)?,"source_sha256":bytes_sha256(include_bytes!("main.rs")),"plan_source_sha256":bytes_sha256(include_bytes!("plan.rs")),"math_library_sha256":args.math_library.as_ref().map(|p|file_sha256(p)).transpose()?,"soxr_wrapper_sha256":args.soxr_wrapper.as_ref().map(|p|file_sha256(p)).transpose()?,"owner_source_sha256":owner::identity(),"cases":rows});
    fs::write(&args.output, serde_json::to_vec_pretty(&result)?)?;
    ensure!(
        passed,
        "Frozen final-logit gate failed (diagnostics preserved)"
    );
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;
    #[test]
    fn basename_manifest_reads_artifacts_from_its_working_directory() -> Result<()> {
        const CHILD: &str = "CQT_BASENAME_READER_CHILD";
        let bytes = 1.0f32.to_le_bytes();
        if std::env::var_os(CHILD).is_some() {
            let artifact = json!({"path":"pcm","sha256":bytes_sha256(&bytes),"bytes":4});
            ensure!(read_f32(artifact_root(Path::new("manifest.json"))?, &artifact)? == [1.0]);
            return Ok(());
        }
        let root = std::env::temp_dir().join(format!("cqt-basename-{}", std::process::id()));
        fs::create_dir(&root)?;
        fs::write(root.join("pcm"), bytes)?;
        let output = std::process::Command::new(std::env::current_exe()?)
            .args([
                "--exact",
                "tests::basename_manifest_reads_artifacts_from_its_working_directory",
            ])
            .env(CHILD, "1")
            .current_dir(&root)
            .output()?;
        fs::remove_dir_all(root)?;
        ensure!(
            output.status.success(),
            "basename reader failed: {} {}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        Ok(())
    }
    #[test]
    fn diagnostics_preserve_half_mismatches_and_finites() -> Result<()> {
        let result = diagnostics(&[0., 1.], &[0., 1.001])?;
        ensure!(result["fp16_mismatches"] == 1);
        ensure!(diagnostics(&[f32::NAN], &[0.]).is_err());
        ensure!(diagnostics(&[0.], &[]).is_err());
        Ok(())
    }
    #[test]
    fn raw_artifact_integrity_and_size() -> Result<()> {
        let root = std::env::temp_dir().join(format!("cqt-test-{}", std::process::id()));
        fs::create_dir(&root)?;
        let path = root.join("pcm");
        let bytes = [0u8, 0, 128, 63];
        fs::write(&path, bytes)?;
        let mut artifact = json!({"path":"pcm","sha256":bytes_sha256(&bytes),"bytes":4});
        ensure!(read_f32(&root, &artifact)? == [1.]);
        artifact["bytes"] = json!(8);
        ensure!(read_f32(&root, &artifact).is_err());
        artifact["bytes"] = json!(4);
        artifact["sha256"] = json!("0".repeat(64));
        ensure!(read_f32(&root, &artifact).is_err());
        let nan = f32::NAN.to_le_bytes();
        fs::write(&path, nan)?;
        artifact["sha256"] = json!(bytes_sha256(&nan));
        ensure!(read_f32(&root, &artifact).is_err());
        #[cfg(unix)]
        {
            std::os::unix::fs::symlink("/etc/hosts", root.join("escape"))?;
            artifact["path"] = json!("escape");
            ensure!(read_f32(&root, &artifact).is_err());
        }
        fs::remove_dir_all(root)?;
        Ok(())
    }
}
