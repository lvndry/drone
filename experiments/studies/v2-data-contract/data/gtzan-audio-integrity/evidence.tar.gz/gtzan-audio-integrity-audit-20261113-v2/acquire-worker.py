import json,pathlib,time
from tools.check_gtzan_audio import audit
ROOT=pathlib.Path('/home/lysk-admin/drone-experiments/gtzan-audio-integrity-audit-20261113-v2')
start=time.monotonic()
result=audit(pathlib.Path('/home/lysk-admin/drone-experiments/gtzan-audio-integrity-20261113-v1/genres.tar.gz'))
with (ROOT/'audio-integrity.json').open('x') as out:json.dump(result,out,indent=2,sort_keys=True);out.write('\n')
print(json.dumps({'identity_verified_recordings':len(result['records']),'admitted_for_scoring':False,'elapsed_seconds':time.monotonic()-start}),flush=True)
