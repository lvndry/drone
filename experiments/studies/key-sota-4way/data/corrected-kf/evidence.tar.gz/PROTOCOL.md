# One bounded corrected KeyFinder rerun of PR41's fixed 93 recordings

Frozen before any new KeyFinder outputs. PR head:
`f101331db20b98348ab6356b22bd72517da90198`. The original CSV/JSON/manifest,
old harness, faulty CLI, corrected CLI/source, KeyFinder shared library, FFTW
and ffmpeg hashes are explicit in runner.py and copied into plan.json. The plan
also seals the runner/protocol/Python bytes, all 93 source-container hashes,
retained WAV container/PCM hashes and exact PCM parameters before measurement.
Preparation reads/hashes only. No corrected output exists during planning.

One execution, CSV order, all 93 original IDs/references; no exclusions,
substitutions, retries, score tuning or alternative detector settings. For each
recording use the original source path and this exact old decode argv, with only
absolute executable and task-owned output path made explicit:

`/usr/bin/ffmpeg -loglevel error -y -i SOURCE -ac 1 -ar 44100 -c:a pcm_s16le current.wav`

Before the corrected CLI call, require PCM SHA256, byte count, channels, sample
width, rate, frame count and compression to equal the retained benchmark WAV.
Container/header differences alone are allowed and recorded. Any PCM mismatch,
changed input, decode failure, invalid output, reserve violation or resource
breach stops the entire run; no rescue. Old predictions may only be reused for
aggregate reporting if all 93 PCM comparisons pass and the controller completes.

Run the already qualified binary once per passing WAV, default keyOfAudio
settings, recording its raw JSON (raw enum, normalized class, tonic/mode/status),
command, wall/CPU and per-command wait4 peak RSS. Silence is an explicit abstention
and must receive zero in later full-denominator scoring. Errors are terminal,
not dropped rows. This job produces raw evidence only; root separately aggregates
fixed original Drone/madmom predictions and corrected KF outputs. No Torch,
madmom, GPU, label repair, original-file modification or environment installation.

Measurement bounds:900 seconds wall,1200 aggregate CPU seconds,1GiB owned-tree
RSS,64MiB outputs, CPUs10–11 nice19. At most one owned temporary WAV, at most30MiB,
removed after each row or terminal failure. Maintain40GiB available host memory
and32GiB disk; preserve PID/start ticks1478814/35698640,1481756/35700162,
3448680/111966827,3451013/111967770. Guardian samples at0.25s; subinterval spikes
may not be observed. Supplement with inherited address-space/CPU/file-size
limits. Kill only the owned worker process group on failure. No restart.

The guardian seals launch/controller identities and hashes; child logs and
per-row evidence remain in the new task directory. Retain failed evidence as
failed. The old server outputs, source, decoded WAVs and CLI remain unchanged.
