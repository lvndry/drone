"""Frozen 93-track KF repair. Stdlib only; no score aggregation or model tuning."""
import csv
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
import wave

ROOT = Path(__file__).resolve().parent
OLD = Path('/home/lysk-admin/drone-bench')
BASE = Path('/home/lysk-admin/drone-experiments/native-baseline-20261111')
FIX = Path('/home/lysk-admin/drone-experiments/keyfinder-reference-fix-20261113-v1')
PROTECTED = {1478814:35698640, 1481756:35700162, 3448680:111966827, 3451013:111967770}
PINS = {
 OLD/'results/bench.csv':'5c607d1def5f301674f205d0f51ccc140fc17880b24ade625898baf5ff190922',
 OLD/'results/bench.json':'d0b2c86490777d0dc9cbc2968d4d221d7653647ac611839648ab21351feda1e3',
 OLD/'results/manifest.json':'e03ebcbafb9b111775f8278161510ac153f3177ea2c2d6b96738b77b26e11304',
 OLD/'harness.py':'f113228e74770e71087c6bba075c4a908a530c1978f4157505df936318b4b38b',
 OLD/'kf_cli':'a8af5fbd4a5b4d8973687d0002c9036e3aea36c39c7340558a350e14ba79c6d3',
 FIX/'keyfinder_reference':'3be7ac37598aeef09af1b9f2f002e139d5b920888a6fef197f40e70c66a1764a',
 FIX/'keyfinder_reference.cpp':'a407aebf8b877d392f526b9df9885b4fd5094153735bd5a50fa8cfa29d54a781',
 BASE/'keyfinder-build/libkeyfinder.so.2.2.8':'f475cde06faa3e2ace1d6d8e544076b4d75d168417c303c9808b0c5397948128',
 BASE/'prefix/usr/lib/x86_64-linux-gnu/libfftw3.so.3':'b5cc02c4d360b5b20111cb0a251f8368af8c9ce3145357f5ba54c51ac4ca9b35',
 Path('/usr/bin/ffmpeg'):'ed16af623947494a72e284b6eb8ff225f2da22b38b5d5069c2fd4b4ba3384e41',
}
ENV = {'PATH':'/usr/bin:/bin', 'LC_ALL':'C', 'CUDA_VISIBLE_DEVICES':'',
       'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):
            digest.update(block)
    return digest.hexdigest()

def write(name, value):
    path=ROOT/name
    with path.open('x') as f:
        json.dump(value,f,indent=2)
        f.write('\n')

def stat(pid):
    raw=Path(f'/proc/{pid}/stat').read_text()
    return raw[raw.rfind(')')+2:].split()

def reserves():
    for pid,start in PROTECTED.items():
        assert int(stat(pid)[19])==start, f'protected process changed: {pid}'
    mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
    assert int(mem['MemAvailable'].split()[0])*1024>=40*2**30, 'host reserve'
    assert shutil.disk_usage(ROOT).free>=32*2**30, 'disk reserve'
    assert sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())<=64*2**20, 'output cap'
    if (ROOT/'current.wav').exists():
        assert (ROOT/'current.wav').stat().st_size<=30*2**20, 'WAV cap'

def check_pins():
    for path,digest in PINS.items():
        assert sha(path)==digest, f'pin changed: {path}'

def audio_identity(path):
    # Container bytes plus exact PCM bytes and decoding parameters, independently of headers.
    with wave.open(str(path),'rb') as f:
        params={'channels':f.getnchannels(),'sample_width':f.getsampwidth(),
                'sample_rate':f.getframerate(),'frames':f.getnframes(),'compression':f.getcomptype()}
        assert params['channels']==1 and params['sample_width']==2
        assert params['sample_rate']==44100 and params['compression']=='NONE'
        digest=hashlib.sha256(); count=0
        while True:
            block=f.readframes(2**18)
            if not block: break
            digest.update(block); count+=len(block)
        assert count==params['frames']*2 and count>0, 'truncated PCM'
    return {'container_sha256':sha(path),'container_bytes':path.stat().st_size,
            'pcm_sha256':digest.hexdigest(),'pcm_bytes':count,'parameters':params}

def prepare():
    reserves(); check_pins()
    with (OLD/'results/bench.csv').open(newline='') as f: rows=list(csv.DictReader(f))
    manifest=json.loads((OLD/'results/manifest.json').read_text())
    assert len(rows)==93 and manifest['n']==93 and len(manifest['tracks'])==93
    assert len({r['track_id'] for r in rows})==93
    planned=[]
    for row,original in zip(rows,manifest['tracks'],strict=True):
        reserves()
        tid=row['track_id']; assert '/' not in tid and '..' not in tid
        assert tid==original['track_id'] and int(row['ref'])==original['ref']
        assert row['ref_raw']==original['ref_raw'] and row['source']==original['source']
        if tid.startswith('swd-'):
            source=Path('/home/lysk-admin/drone-data/swd-v2.1/extracted/01_RawData/audio_wav')/(tid[4:]+'.wav')
        elif tid.startswith('gs-'):
            source=Path('/home/lysk-admin/key-cnn/data/giantsteps/audio')/(tid[3:]+'.mp3')
        else: raise AssertionError('unexpected track ID')
        assert source.is_file()
        oldwav=OLD/'decode'/(tid+'.wav'); assert oldwav.is_file()
        old=audio_identity(oldwav)
        assert old['container_bytes']<=30*2**20
        planned.append({'track_id':tid,'ref':int(row['ref']),'ref_raw':row['ref_raw'],
                        'source':str(source),'source_sha256':sha(source),
                        'source_bytes':source.stat().st_size,'retained_wav':str(oldwav),
                        'retained_audio':old})
    write('plan.json',{'schema':'drone.kf93-repair.plan.v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
          'pr_head':'f101331db20b98348ab6356b22bd72517da90198',
          'pins':{str(p):s for p,s in PINS.items()},'protected':PROTECTED,
          'runner_sha256':sha(Path(__file__)),'protocol_sha256':sha(ROOT/'PROTOCOL.md'),
          'python_executable':sys.executable,'python_sha256':sha(Path(sys.executable).resolve()),
          'environment':ENV,'rows':planned})
    reserves()
    print(json.dumps({'prepared':93,'plan_sha256':sha(ROOT/'plan.json')}),flush=True)

def command(argv, prefix):
    wall=time.monotonic()
    with (ROOT/(prefix+'.stdout')).open('xb') as out,(ROOT/(prefix+'.stderr')).open('xb') as err:
        proc=subprocess.Popen(argv,stdout=out,stderr=err,env=ENV)
        pid,status,usage=os.wait4(proc.pid,0)
        proc.returncode=os.waitstatus_to_exitcode(status)
    record={'argv':argv,'pid':pid,'exit_code':proc.returncode,'wall_seconds':time.monotonic()-wall,
            'cpu_seconds':usage.ru_utime+usage.ru_stime,'max_rss_bytes':usage.ru_maxrss*1024,
            'stdout_sha256':sha(ROOT/(prefix+'.stdout')),'stderr_sha256':sha(ROOT/(prefix+'.stderr'))}
    write(prefix+'.command.json',record)
    assert proc.returncode==0, f'{prefix} failed'
    assert (ROOT/(prefix+'.stdout')).stat().st_size<=16384, 'unexpected command output'
    return record

def verify_plan(expected):
    assert sha(ROOT/'plan.json')==expected,'plan hash'
    plan=json.loads((ROOT/'plan.json').read_text())
    assert plan['runner_sha256']==sha(Path(__file__))
    assert plan['protocol_sha256']==sha(ROOT/'PROTOCOL.md')
    assert plan['python_sha256']==sha(Path(sys.executable).resolve())
    assert plan['pins']=={str(p):s for p,s in PINS.items()}
    assert plan['environment']==ENV
    assert len(plan['rows'])==93
    return plan

def worker(expected):
    plan=verify_plan(expected); check_pins()
    write('worker-start.json',{'pid':os.getpid(),'start_ticks':int(stat(os.getpid())[19]),
          'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'plan_sha256':expected,
          'affinity':sorted(os.sched_getaffinity(0)),'nice':os.getpriority(os.PRIO_PROCESS,0)})
    temp=ROOT/'current.wav'; assert not temp.exists()
    for index,row in enumerate(plan['rows']):
        reserves()
        source=Path(row['source']); oldwav=Path(row['retained_wav'])
        assert sha(source)==row['source_sha256'],'source changed before decode'
        assert audio_identity(oldwav)==row['retained_audio'],'retained WAV changed'
        name=f'row-{index:03d}'
        decoded=command(['/usr/bin/ffmpeg','-loglevel','error','-y','-i',str(source),
                         '-ac','1','-ar','44100','-c:a','pcm_s16le',str(temp)],name+'-decode')
        assert temp.stat().st_size<=30*2**20
        fresh=audio_identity(temp)
        assert sha(source)==row['source_sha256'],'source changed during decode'
        equivalent=all(fresh[key]==row['retained_audio'][key] for key in ('parameters','pcm_sha256','pcm_bytes'))
        equivalence={'track_id':row['track_id'],'fresh':fresh,'retained':row['retained_audio'],
                     'pcm_equivalent':equivalent,'container_identical':fresh['container_sha256']==row['retained_audio']['container_sha256']}
        write(name+'-equivalence.json',equivalence)
        assert equivalent, f'PCM mismatch {row["track_id"]}'
        measured=command([str(FIX/'keyfinder_reference'),str(temp)],name+'-keyfinder')
        result=json.loads((ROOT/(name+'-keyfinder.stdout')).read_text())
        assert set(result)=={'schema','raw_enum','status','tonic','mode','drone_class'}
        assert result['schema']=='drone.keyfinder-reference.v1'
        raw=result['raw_enum']; code=result['drone_class']
        assert type(raw) is int and 0<=raw<=24
        if raw==24:
            assert result['status']=='silence' and code is None and result['tonic'] is None and result['mode'] is None
        else:
            assert result['status']=='key' and type(code) is int and code==((9+raw//2)%12)*2+raw%2
            assert result['tonic']==['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'][code//2]
            assert result['mode']==('minor' if code%2 else 'major')
        write(name+'-result.json',{'index':index,'track_id':row['track_id'],'prediction':result,
              'equivalence':equivalence,'decode':decoded,'keyfinder':measured})
        temp.unlink() # Only this new task-owned temporary is removed.
        if (index+1)%5==0: print(json.dumps({'completed':index+1,'total':93}),flush=True)
    check_pins(); verify_plan(expected)
    for row in plan['rows']:
        assert sha(Path(row['source']))==row['source_sha256']
        assert audio_identity(Path(row['retained_wav']))==row['retained_audio']
    reserves()
    write('worker-complete.json',{'status':'COMPLETE','rows':93,'pcm_equivalent':93,
          'plan_sha256':expected,'result_hashes':{p.name:sha(p) for p in sorted(ROOT.glob('row-*-result.json'))}})

def limits():
    os.sched_setaffinity(0,{10,11}); os.nice(19)
    resource.setrlimit(resource.RLIMIT_CPU,(1200,1200))
    resource.setrlimit(resource.RLIMIT_AS,(2**30,2**30))
    resource.setrlimit(resource.RLIMIT_FSIZE,(30*2**20,30*2**20))

def guard(expected):
    plan=verify_plan(expected); reserves(); check_pins()
    started=time.monotonic(); peak_rss=0; peak_cpu=0.0; proc=None
    hz=os.sysconf('SC_CLK_TCK'); page=os.sysconf('SC_PAGE_SIZE')
    receipt={'schema':'drone.kf93-repair.controller.v1','plan_sha256':expected,
             'protected':PROTECTED,'controller_pid':os.getpid(),'controller_start_ticks':int(stat(os.getpid())[19]),
             'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    def stop(signum,frame): raise RuntimeError(f'controller signal {signum}')
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    try:
        with (ROOT/'worker.log').open('xb') as out:
            proc=subprocess.Popen([sys.executable,str(Path(__file__)),'worker',expected],
                 stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits,env=ENV)
            receipt['worker_pid']=proc.pid; receipt['worker_start_ticks']=int(stat(proc.pid)[19])
            write('launch.json',receipt)
            print(json.dumps(receipt),flush=True)
            while proc.poll() is None:
                reserves()
                assert time.monotonic()-started<=900,'wall cap'
                own=resource.getrusage(resource.RUSAGE_SELF)
                seconds=own.ru_utime+own.ru_stime; rss=0
                for entry in Path('/proc').iterdir():
                    if not entry.name.isdigit(): continue
                    try:
                        fields=stat(entry.name)
                        if int(fields[2])==proc.pid or int(entry.name)==os.getpid():
                            rss+=int(fields[21])*page
                            if int(entry.name)!=os.getpid(): seconds+=sum(int(fields[i]) for i in (11,12,13,14))/hz
                    except (FileNotFoundError,PermissionError,ProcessLookupError): pass
                peak_rss=max(peak_rss,rss); peak_cpu=max(peak_cpu,seconds)
                assert rss<=2**30,'aggregate RSS cap'
                assert seconds<=1200,'aggregate CPU cap'
                time.sleep(0.25)
            assert proc.returncode==0,f'worker exit {proc.returncode}'
        reserves(); check_pins(); verify_plan(expected)
        complete=json.loads((ROOT/'worker-complete.json').read_text())
        assert complete['rows']==93 and complete['pcm_equivalent']==93 and len(complete['result_hashes'])==93
        usage=resource.getrusage(resource.RUSAGE_CHILDREN); own=resource.getrusage(resource.RUSAGE_SELF)
        cpu=usage.ru_utime+usage.ru_stime+own.ru_utime+own.ru_stime
        assert cpu<=1200 and time.monotonic()-started<=900
        receipt.update(status='COMPLETE',rows=93,pcm_equivalent=93,cpu_seconds=cpu,
                       worker_complete_sha256=sha(ROOT/'worker-complete.json'))
    except BaseException as exc:
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid,signal.SIGKILL); proc.wait()
        receipt.update(status='FAIL',error=str(exc))
    finally:
        if (ROOT/'current.wav').exists():
            (ROOT/'current.wav').unlink()
        receipt.update(wall_seconds=time.monotonic()-started,sampled_peak_rss_bytes=peak_rss,
                       conservative_sampled_cpu_seconds=peak_cpu,
                       finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
        write('controller.json',receipt)
    print(json.dumps(receipt),flush=True)
    return 0 if receipt['status']=='COMPLETE' else 1

if __name__=='__main__':
    if sys.argv[1]=='prepare': prepare()
    elif sys.argv[1]=='worker': worker(sys.argv[2])
    elif sys.argv[1]=='guard': sys.exit(guard(sys.argv[2]))
    else: raise SystemExit('unknown stage')
