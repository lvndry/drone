import hashlib,json,pathlib,time,urllib.request
from tools.check_gtzan_audio import ARCHIVE_BYTES,ARCHIVE_SHA256,URL,audit
ROOT=pathlib.Path('/home/lysk-admin/drone-experiments/gtzan-audio-integrity-20261113-v1')
start=time.monotonic();part=ROOT/'genres.tar.gz.partial';digest=hashlib.sha256();size=0
with part.open('xb') as output:
 with urllib.request.urlopen(urllib.request.Request(URL,headers={'User-Agent':'Drone-recording-integrity-research'}),timeout=30) as response:
  declared=response.headers.get('Content-Length')
  if declared is not None and int(declared)!=ARCHIVE_BYTES:raise ValueError('Unexpected declared archive length')
  while chunk:=response.read(1024**2):
   size+=len(chunk)
   if size>ARCHIVE_BYTES:raise ValueError('Download byte cap')
   digest.update(chunk);output.write(chunk)
assert size==ARCHIVE_BYTES and digest.hexdigest()==ARCHIVE_SHA256,'Archive integrity mismatch'
final=ROOT/'genres.tar.gz';assert not final.exists();part.rename(final)
(ROOT/'download.json').write_text(json.dumps({'url':URL,'bytes':size,'sha256':digest.hexdigest(),'seconds':time.monotonic()-start},indent=2)+'\n')
result=audit(final)
with (ROOT/'audio-integrity.json').open('x') as out:json.dump(result,out,indent=2,sort_keys=True);out.write('\n')
print(json.dumps({'identity_verified_recordings':len(result['records']),'admitted_for_scoring':False,'elapsed_seconds':time.monotonic()-start}),flush=True)
