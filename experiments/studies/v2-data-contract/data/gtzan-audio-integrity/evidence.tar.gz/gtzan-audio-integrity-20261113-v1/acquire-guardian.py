import hashlib,json,os,pathlib,resource,signal,subprocess,tarfile,time,traceback
ROOT=pathlib.Path('/home/lysk-admin/drone-experiments/gtzan-audio-integrity-20261113-v1')
CONFIG=json.loads((ROOT/'drone-gtzan-audio-config.json').read_bytes());caps=CONFIG['caps']
def identity(pid):
 try:
  fields=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
  return int(fields[19]),fields[0],(int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')
 except FileNotFoundError:return None

def guard(remaining):
 for pid,start in CONFIG['protected_starts'].items():
  p=identity(pid)
  if p is None or p[0]!=start or p[1] in {'Z','X'}:raise RuntimeError('Protected service identity changed')
 mem={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')}
 if mem['MemAvailable']<40*1024**3:raise RuntimeError('Host memory reserve')
 stat=os.statvfs(ROOT)
 if stat.f_bavail*stat.f_frsize<32*1024**3+remaining:raise RuntimeError('Disk reserve')
 size=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
 if size>caps['output_bytes']:raise RuntimeError('Owned output cap')

def rss(pid):
 try:
  for line in pathlib.Path(f'/proc/{pid}/status').read_text().splitlines():
   if line.startswith('VmRSS:'):return int(line.split()[1])*1024
 except FileNotFoundError:pass
 return 0
start=time.monotonic();p=None;worker_start=None;state='FAILED';error=None;peaks={'rss_bytes':0,'cpu_seconds':0}
try:
 archive=ROOT/'drone-gtzan-audio-source.tar'
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==CONFIG['archive_sha256']
 (ROOT/'source').mkdir(exist_ok=False)
 with tarfile.open(archive) as t:t.extractall(ROOT/'source',filter='data')
 for name,sha in CONFIG['source_sha256'].items():assert hashlib.sha256((ROOT/'source'/name).read_bytes()).hexdigest()==sha
 guard(1_226_192_050)
 os.sched_setaffinity(0,{10,11});os.nice(19)
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
 for key in ['PYTHONPATH','PYTHONHOME']:env.pop(key,None)
 # Use -c to keep the verified source root first on sys.path; do not import site packages.
 code="exec(compile(open("+repr(str(ROOT/'acquire-worker.py'))+").read(), 'acquire-worker.py', 'exec'))"
 with (ROOT/'worker.log').open('xb') as log:
  p=subprocess.Popen(['/usr/bin/python3','-S','-c',code],cwd=ROOT/'source',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 worker_start=identity(p.pid)[0]
 (ROOT/'launch.json').write_text(json.dumps({'worker_pid':p.pid,'worker_start_ticks':worker_start,'guardian_pid':os.getpid(),'guardian_start_ticks':identity(os.getpid())[0],'source_commit':CONFIG['source_commit']},indent=2)+'\n')
 while True:
  live=identity(p.pid);r=resource.getrusage(resource.RUSAGE_SELF);children=resource.getrusage(resource.RUSAGE_CHILDREN)
  cpu=r.ru_utime+r.ru_stime+children.ru_utime+children.ru_stime+(live[2] if live is not None else 0)
  memory=rss(os.getpid())+rss(p.pid)
  peaks['rss_bytes']=max(peaks['rss_bytes'],memory);peaks['cpu_seconds']=max(peaks['cpu_seconds'],cpu)
  if memory>caps['rss_bytes'] or cpu>caps['cpu_seconds'] or time.monotonic()-start>caps['wall_seconds']:raise RuntimeError('Whole-tree resource cap')
  guard(0)
  if p.poll() is not None:break
  time.sleep(.1)
 if p.returncode!=0:raise RuntimeError('Acquisition worker failed: '+str(p.returncode))
 result=json.loads((ROOT/'audio-integrity.json').read_bytes())
 assert len(result['records'])==1000 and result['admitted_for_scoring'] is False
 state='COMPLETE_RECORDING_IDENTITY_ONLY'
except BaseException as e:
 error=repr(e);traceback.print_exc()
finally:
 if p is not None and p.poll() is None:
  live=identity(p.pid)
  if live is not None and live[0]==worker_start:p.terminate()
  try:p.wait(timeout=2)
  except subprocess.TimeoutExpired:
   live=identity(p.pid)
   if live is not None and live[0]==worker_start:p.kill()
   p.wait(timeout=2)
 (ROOT/'controller.json').write_text(json.dumps({'state':state,'error':error,'peaks':peaks,'wall_seconds':time.monotonic()-start,'worker_exit':None if p is None else p.returncode},indent=2)+'\n')
